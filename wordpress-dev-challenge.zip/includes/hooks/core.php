<?php

if ( ! defined('ABSPATH') ) {
    die('Direct access not permitted.');
}